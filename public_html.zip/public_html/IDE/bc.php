 <title>BuildersCLUB - FIEI-v2</title>
<link rel="stylesheet" href="rbx2.css">
   <div id="Header">
                <div id="Banner">
                    
                            

<div id="Options">
  <div id="Authentication">
    <span><a id="ctl00_BannerOptionsLoginView_BannerOptions_Anonymous_LoginHyperLink" href="Login/Default.aspx">Login</a></span>
  </div>
  <div id="Settings"></div>
</div>
                            <a id="Logo" href="/web/20100409214230/http://www.FIEI_V2.com/Default.aspx" style="cursor: pointer; border: none;"></a>
                        
                    
                            
<div style="float: right; width: 203px;">
    <a id="ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink" class="SignUpAndPlay" text="Sign-up and Play!" href="/web/20100409214230/http://www.FIEI_V2.com/Games.aspx" style="display:inline-block;cursor:pointer;"><img src="/web/20100409214230im_/http://www.FIEI_V2.com/images/Holiday3Button.png" border="0" onerror="return FIEI_V2.Controls.Image.OnError(this)" blankurl="http://t1bg.FIEI_V2.com/blank-210x40.gif"/></a>


</div>

                        
                </div>
                
<div class="Navigation">
    <ul id="ctl00_Menu_MenuUL">
        
                <li>
                    <a id="ctl00_Menu_hlMyFIEI_V2Link_hlMyFIEI_V2" href="ps1.php" style="">My FIEI_V2 (hardcoded)</a></li>
            
        <li><a id="hlGames" href="Landing.aspx" style="font-weight: bold" title="Games">Games</a>
            <!-- TODO: make compatible with shadowed elements on site, then turn on
            <ul>
                <li>
                    <div class="dropdownmainnav" style="height:250px;z-index:99999;">
                        
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Classic.png" />
                                    <a href='/all-games'
                                        title="All" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        All</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/City.png" />
                                    <a href='/town-and-city-games'
                                        title="Town and City" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Town and City</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Castle.png" />
                                    <a href='/medieval-games'
                                        title="Medieval" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Medieval</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/SciFi.png" />
                                    <a href='/sci-fi-games'
                                        title="Sci-Fi" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Sci-Fi</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Ninja.png" />
                                    <a href='/ninja-games'
                                        title="Ninja" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Ninja</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Cthulu.png" />
                                    <a href='/scary-games'
                                        title="Horror" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Horror</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Pirate.png" />
                                    <a href='/pirate-games'
                                        title="Pirate" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Pirate</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Adventure.png" />
                                    <a href='/adventure-games'
                                        title="Adventure" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Adventure</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Sports.png" />
                                    <a href='/sports-games'
                                        title="Sports" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Sports</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/LOL.png" />
                                    <a href='/funny-games'
                                        title="LOL" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        LOL</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/WildWest.png" />
                                    <a href='/wild-west-cowboy-games'
                                        title="Wild West" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Wild West</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/ModernMilitary.png" />
                                    <a href='/war-games'
                                        title="Modern Military" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Modern Military</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Skatepark.png" />
                                    <a href='/skatepark-games'
                                        title="Skate Park" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Skate Park</a>
                                </div>
                            
                    </div>
                    
                    <div class="dropdownmainnav" style="height:250px;width:145px;border-left:0px;z-index:99999">
                             <a href="/games.aspx" style="font-size:15px;"><b>Most Popular</b></a>
                             <a href="/games.aspx?m=TopFavorites" style="font-size:15px;">Top Favorites</a>
                             <a href="/games.aspx?m=RecentlyUpdated" style="font-size:15px;">Recently Updated</a>
                             <a href="/user.aspx?id=1" style="font-size:15px;">Featured Games</a>
                             <a href="#" style="font-size:15px;">Search Games</a>
                    </div>
                </li>
            </ul>
            -->
            
        </li>
        <li><a id="hlBuildersClub" href="bc.php" style="" title="Builders Club">Builders Club</a></li>
        <li><a id="hlHelp" href="eek.php" style="" title="Help">Help</a></li>
    </ul>
</div>

            </div>
            <div id="ctl00_Announcement">
  
                <div class="SystemAlert">
                    <div id="ctl00_SystemAlertTextColor" class="SystemAlertText" style="background-color:orange;">
                        <div class="Exclamation">
                        </div>
                        <div id="ctl00_LabelAnnouncement">Are you an experienced FIEIian?  Come help us test at {{{{no}}}}}</div>
                    </div>
                </div>
            
</div>
            <div id="Body">
                
    
    <div id="GamesContainer">
        
<div id="ctl00_cphFIEI_V2_rbxGames_GamesContainerPanel">
  
    <!--[if IE 6]>
<table width="900px">
<tr>
<td width="143px" align="left" valign="top">

</td>
<td valign="top" width="800" align="left">
<![endif]-->
           
            
   
           
           
            <div id="Body">
                
    <div id="BuildersClubContainer">
        <!--<div id="JoinBuildersClubNow"><img id="ctl00_cphRoblox_HeaderImage" src="../images/JoinBuildersClubNow.png" alt="Join Builders Club Now!" border="0" /></div>!-->
        <div id="LeftColumn">
            <div id="ctl00_cphRoblox_MembershipPanelStyle2">
  
                <div id="MembershipOptions" style="margin-bottom: 18px;">
                    <div style="height: 35px;">
                        <h1 id="BuildersClubTitle" style="float: left; width: 480px; margin: 0;">
                            Builders Club</h1>
                        <input type="image" name="ctl00$cphRoblox$ImageButton1" id="ctl00_cphRoblox_ImageButton1" src="/web/20100627051438im_/http://www.roblox.com/images/Buttons/questionmark-25x25.png" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$ImageButton1&quot;, &quot;&quot;, false, &quot;&quot;, &quot;../Parents/BuildersClub.aspx&quot;, false, false))" border="0" style="float: left"/>
                        <div class="icons obc_icon" onclick="animateOBC()" id="OBCSell" alt="Outrageous Builders Club - VIP Only" style="cursor: pointer; margin-left: 10px;"></div>
                    </div>
                    <div id="OneMonth" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_BCMonthlyImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$BCMonthlyImageLinkButton','')"><div id="ctl00_cphRoblox_BCMonthlyImageLink" class="upgrades_enabled bcmonthly"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="SixMonths" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_BC6MonthsImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$BC6MonthsImageLinkButton','')"><div id="ctl00_cphRoblox_BC6MonthsImageLink" class="upgrades_enabled bc6"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="TwelveMonths" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_BC12MonthsImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$BC12MonthsImageLinkButton','')"><div id="ctl00_cphRoblox_BC12MonthsImageLink" class="upgrades_enabled bc12"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="Lifetime" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_BCLifetimeImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$BCLifetimeImageLinkButton','')"><div id="ctl00_cphRoblox_BCLifetimeImageLink" class="upgrades_enabled bclife"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div style="clear: both; padding-top: 10px; height: 35px;">
                        <h1 id="TurboBuildersClubTitle" style="margin: 0;">
                            <span class="TurboSpan">Turbo</span> Builders Club</h1>
                    </div>
                    <div id="TurboMonthly" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_TBCMonthlyImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$TBCMonthlyImageLinkButton','')"><div id="ctl00_cphRoblox_TBCMonthlyImageLink" class="upgrades_enabled tbcmonthly"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="TurboSixMonths" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_TBC6MonthsImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$TBC6MonthsImageLinkButton','')"><div id="ctl00_cphRoblox_TBC6MonthsImageLink" class="upgrades_enabled tbc6"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="TurboTwelveMonths" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_TBC12MonthsImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$TBC12MonthsImageLinkButton','')"><div id="ctl00_cphRoblox_TBC12MonthsImageLink" class="upgrades_enabled tbc12"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                    <div id="TurboLifetime" class="MembershipButton">
                        <div class="BuildersClubButton">
                            <a id="ctl00_cphRoblox_TBCLifetimeImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$TBCLifetimeImageLinkButton','')"><div id="ctl00_cphRoblox_TBCLifetimeImageLink" class="upgrades_enabled tbclife"></div></a>
                        </div>
                        <div class="BCButtonLabel">
                            
                        </div>
                    </div>
                </div>
            
</div>
            <br/>
            <br/>
            <div style="height: 15px; clear: both">
                &nbsp;</div>
            <!-- Spacer -->
            <table id="upgrades-membership-options" style="padding-top: 10px;">
                <thead>
                    <tr>
                        <th scope="col">
                        </th>
                        <th scope="col" class="LeftText">
                            Benefits
                        </th>
                        <th scope="col" class="leftBorder">
                            <p style="line-height: 20px">
                                Free Account</p>
                        </th>
                        <th scope="col" class="leftBorder">
                            <div>
                                <div style="margin-top: 4px; float: left;" class="icons bc_icon"></div><p style="line-height: 20px">
                                    Builders Club</p>
                            </div>
                        </th>
                        <th scope="col" class="leftBorder">
                            <div>
                                <div style="margin-top: 4px; float: left;" class="icons tbc_icon"></div><p style="line-height: 20px">
                                    Turbo Builders Club</p>
                            </div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="odd">
                        <td>
                            <div class="icons maps_icon"></div>
                        </td>
                        <td class="LeftText">
                            Active Places
                        </td>
                        <td class="leftBorder">
                            1
                        </td>
                        <td class="leftBorder">
                            10
                        </td>
                        <td class="leftBorder">
                            25
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="icons money_icon"></div>
                        </td>
                        <td class="LeftText">
                            Daily ROBUX
                        </td>
                        <td class="leftBorder">
                            None
                        </td>
                        <td class="leftBorder">
                            15 R$
                        </td>
                        <td class="leftBorder">
                            35 R$
                        </td>
                    </tr>
                    <tr class="odd">
                        <td>
                            <div class="icons shirt_icon"></div>
                        </td>
                        <td class="LeftText">
                            Sell Stuff
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="icons ads_icon"></div>
                        </td>
                        <td class="LeftText">
                            See Ads
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                    </tr>
                    <tr class="odd">
                        <td>
                            <div class="icons bc_icon"></div>
                        </td>
                        <td class="LeftText">
                            Virtual Hat
                        </td>
                        <td class="leftBorder">
                            None
                        </td>
                        <td class="leftBorder">
                            <div class="icons bc_icon"></div>
                        </td>
                        <td class="leftBorder">
                            <div class="icons tbc_icon"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="icons gear_icon"></div>
                        </td>
                        <td class="LeftText">
                            Bonus Gear Item
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                    </tr>
                    <tr class="odd">
                        <td>
                            <div class="icons money_icon"></div>
                        </td>
                        <td class="LeftText">
                            Signing Bonus
                        </td>
                        <td class="leftBorder">
                            None
                        </td>
                        <td class="leftBorder">
                            100 R$
                        </td>
                        <td class="leftBorder">
                            100 R$
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="icons groups_icon"></div>
                        </td>
                        <td class="LeftText">
                            Create Groups
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            Yes (10)
                        </td>
                        <td class="leftBorder">
                            Yes (20)
                        </td>
                    </tr>
                    <tr class="odd">
                        <td>
                            <div class="icons groups_icon"></div>
                        </td>
                        <td class="LeftText">
                            Join Groups
                        </td>
                        <td class="leftBorder">
                            Yes (5)
                        </td>
                        <td class="leftBorder">
                            Yes (10)
                        </td>
                        <td class="leftBorder">
                            Yes (20)
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="icons badges_icon"></div>
                        </td>
                        <td class="LeftText">
                            Create Badges
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                    </tr>
                    <tr class="odd">
                        <td>
                            <div class="icons beta_icon"></div>
                        </td>
                        <td class="LeftText">
                            BC Beta Features
                        </td>
                        <td class="leftBorder">
                            No
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                        <td class="leftBorder">
                            Yes
                        </td>
                    </tr>
                </tbody>
            </table>
            <div id="WindowsOnlyWarning">
                <p>
                    Product is Windows-only. For more information, read our
                    <a id="ctl00_cphRoblox_FAQHyperLink" href="/web/20100627051438/http://www.roblox.com/Parents/BuildersClub.aspx">Builders Club FAQs</a>.</p>
                <p>
                    All items and gear are virtual.</p>
            </div>
        </div>
        <div id="RightColumn">
            <div id="ManageAccount" class="RightColumnManageAccount">
                <div id="ManageAccountBanner">
                    <p id="InnerManageAccountMembership">
                        Manage Account</p>
                </div>
                <div id="ManageAccountBody">
                    
                    <div id="ctl00_cphRoblox_LoggedOutPanel">
  
                        <div id="ManageAccountButton">
                            <a href="/web/20100627051438/http://www.roblox.com/Login/Default.aspx?ReturnURL=%2fUpgrades%2fBuildersClub.aspx">
                                <img src="/web/20100627051438im_/http://www.roblox.com/images/Buttons/ManageAccountButton.png?v=2" name="manageaccountbuttonimg" onmouseout="document.manageaccountbuttonimg.src='../../images/Buttons/ManageAccountButton.png?v=2'" onmouseover="document.manageaccountbuttonimg.src='../../images/Buttons/ManageAccountButtonMouseOver.png?v=2'" alt="You must login to view your account."/>
                            </a>
                        </div>
                        <p>
                            If you forgot your username or password, or you want to cancel the membership of
                            one or more accounts, please contact customer service at info@roblox.com.
                        </p>
                    
</div>
                </div>
            </div>
            

<div id="RobuxBCPane" class="RightColumnBox">
    <a href="Robux.aspx" style="text-decoration:none; cursor: pointer"><img style="float:left; vertical-align:top; border: none;" src="/web/20100627051438im_/http://www.roblox.com/images/AllowanceBullet2.png"/><h1>ROBUX!</h1></a>
    <p style="clear: left">ROBUX is the currency of ROBLOXIA. </p>
    <p>Use ROBUX to buy virtual goods for your character – shirts, pants, hats, faces, and even heads!  You can also buy gear, like hammers, potions, jet boots, swords, and BLOXI Cola.</p>
    
    <p>Builders Club members earn ROBUX every day. Not enough? <a href="Robux.aspx">Buy more here</a>.</p>
    <p>Not ready for Builders Club? <a href="Robux.aspx">Start with some ROBUX</a>.</p>
    
    <p>Low on cash? No credit card? <a href="/web/20100627051438/http://www.roblox.com/rixty">Top Up with Rixty</a></p>
    
</div>

            

<div id="ParentsBCPane" class="RightColumnBox">
    <h1>Parents</h1><img style="float:right; vertical-align:top" src="/web/20100627051438im_/http://www.roblox.com/images/truste_seal_kids-110x37.gif"/> 
    <p style="clear: left">Learn more about builders club and how we help <a href="/web/20100627051438/http://www.roblox.com/Parents/KeepingKidsSafe.aspx">keep kids safe</a>.</p>
    <h3>Other Accounts</h3>
    <p>To cancel the membership for one or more other accounts, please contact customer service at info@roblox.com.</p>
    <p><b>Please Note</b></p>
    <p>You can cancel monthly recurring membership at any time during the billing cycle. 6 and 12 month memberships cannot be canceled.  Memberships are not refundable.</p>
    
</div>
            <div id="ctl00_cphRoblox_ReferAFriend" class="RightColumnBox">
                <a href="/web/20100627051438/http://www.roblox.com/My/Share/ReferralLeaderboards.aspx" title="Referral Leaderboards" style="text-decoration: none;
                    cursor: pointer">
                    <h1>
                        Refer-A-Friend, Get Paid!</h1>
                </a>
                <p style="clear: left">
                    Invite a friend to join Builders Club. Both you and your friend will receive a
                    50
                    ROBUX bonus. Here's your personal referral code:</p>
                <p>
                    <center>
                        <span style="font-size: 25px; color: #6E99C9; margin: 0px; padding: 0px;">
                            Login for code</span></center>
                </p>
            </div>
            

<div id="UpgradeMeBCPane" class="RightColumnBox">
    <a href="/web/20100627051438/http://www.roblox.com/My/Share/PleaseUpgradeMe.aspx" title="Please Upgrade Me!" style="text-decoration:none; cursor: pointer"><h1>Need Builders Club Now?</h1></a>
    <p style="clear: left">Fill out our fun, <a href="/web/20100627051438/http://www.roblox.com/My/Share/PleaseUpgradeMe.aspx" title="Please Upgrade Me!">interactive form</a>, and print it out or send it to your friends and family!</p>
    <p><span style="color: Red">Warning:</span> "<a href="/web/20100627051438/http://www.roblox.com/My/Share/PleaseUpgradeMe.aspx" title="Please Upgrade Me!">Please Upgrade Me!</a>" may be very convincing.</p>
</div>

        </div>
        <div style="clear: both;">
        </div>
    </div>
    <div id="ctl00_cphRoblox_BuyBCComparePanel" class="modalPopup" style="display: none">
  
        <div id="ctl00_cphRoblox_UpdatePanel2">
    
                <div id="BCCompareModal">
                    <div id="BuyBCComparePanelTopInfo">
                        <div id="ComparePanelImg" style="text-align: center;">
                            <img id="ctl00_cphRoblox_BuyBCComparePanelImage" src="/web/20100627051438im_/http://www.roblox.com/Upgrades/BuildersClub.aspx" border="0"/>
                        </div>
                        <span id="ctl00_cphRoblox_BCCompareConversionInfo"></span>
                    </div>
                    <table id="ctl00_cphRoblox_BuyBCComparePanelTable" class="BuyBCComparePanelTable" cellspacing="0" cellpadding="0" align="Center" border="0">
      <tr class="BCCompareHeaderRow">
        <th></th><th>Current Membership</th><th>New Membership</th>
      </tr><tr class="BCCompareRowOdd">
        <td>Recurring</td><td id="ctl00_cphRoblox_recurringCurrent">No</td><td id="ctl00_cphRoblox_recurringNew">No</td>
      </tr><tr class="BCCompareRowEven">
        <td>Expiration / Renewal Date</td><td id="ctl00_cphRoblox_expireCurrent">xx/xx/xx</td><td id="ctl00_cphRoblox_expireNew">xx/xx/xx</td>
      </tr><tr class="BCCompareRowOdd">
        <td>Turbo</td><td id="ctl00_cphRoblox_turboCurrent">No</td><td id="ctl00_cphRoblox_turboNew">No</td>
      </tr><tr class="BCCompareRowEven">
        <td>Outrageous</td><td id="ctl00_cphRoblox_outrageousCurrent">No</td><td id="ctl00_cphRoblox_outrageousNew">No</td>
      </tr>
    </table>
                    <div id="BCCompareButtons">
                        <input type="submit" name="ctl00$cphRoblox$PurchaseLink" value="Purchase" id="ctl00_cphRoblox_PurchaseLink" class="MediumButton" style="cursor: pointer"/>
                        <input type="submit" name="ctl00$cphRoblox$Button1" value="Cancel" onclick="$find('myBehavior4').hide();" id="ctl00_cphRoblox_Button1" class="MediumButton" style="cursor: pointer"/>
                    </div>
                </div>
            
  </div>
    
</div>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField4" id="ctl00_cphRoblox_HiddenField4"/>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField5" id="ctl00_cphRoblox_HiddenField5"/>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField6" id="ctl00_cphRoblox_HiddenField6"/>
    
    <div id="obcContent">
        <div id="ctl00_cphRoblox_setthisonpostback" class="OBCSellSheet" style="display: none;">
            <div>
                <p style="padding: 10px">
                    You’ve stumbled onto a secret little bit of our site: Outrageous Builders Club.</p>
                <p style="padding: 10px">
                    A while back the entire ROBLOX Team was eating lunch. Then Builderman spoke, “Some
                    of our longer-term members are looking for a bigger Builders Club – bigger monthly
                    allowances, more groups, more gear, and LOTS of places to build. Let us create such
                    a club together. We will skin the site in carbon fiber for these users. We will
                    give them piles of ROBUX. And finally, we will host a monthly web cast, taking their
                    questions and feedback. We will call it “Outrageous Builders Club.”
                </p>
                <p style="padding: 10px">
                    We thought for a second. Yes, we decided. That would be outrageous – outrageously
                    awesome.
                </p>
            </div>
            <div style="margin: 0px auto; width: 200px;">
                <div id="OutrageousMonthly" class="MembershipButton">
                    <div class="BuildersClubButton">
                        <a id="ctl00_cphRoblox_OBCMonthlyImageLinkButton" href="javascript:__doPostBack('ctl00$cphRoblox$OBCMonthlyImageLinkButton','')"><img id="ctl00_cphRoblox_OBCMonthlyImageLink" src="/web/20100627051438im_/http://www.roblox.com/images/buyobcmonthly.png" border="0"/></a>
                    </div>
                    <div class="BCButtonLabel">
                        
                    </div>
                </div>
            </div>
            <br clear="all"/>
            <center>
                To purchase Outrageous Builders Club Lifetime, please contact 1-888-858-BLOX (2569)</center>
            <br clear="all"/>
            <div>
                <p>
                    <ul>
                        <li><span class="hoverover">ROBLOX Outrageous website theme</span><em>Unlock the Outrageous
                            theme.</em></li>
                        <li><span class="hoverover">Your profile page, always Outrageous themed</span><em>Everyone
                            will know who you are.</em></li>
                        <li><span class="hoverover">100 active places</span><em>Serious places for serious builders.</em></li>
                        <li><span class="hoverover">100 groups</span><em>With 100 groups, you'll never be lonely.</em></li>
                        <li><span class="hoverover">60 ROBUX every day</span><em>Your bank account will be overflowing.</em></li>
                        <li><span class="hoverover">Outrageous Builders Club hat</span><em>A valuable, rare
                            hat.</em></li>
                        <li><span class="hoverover">Outrageous Builders Club treasure chest</span><em>A collection
                            of awesome items.</em></li>
                        <li><span class="hoverover">Prestigious OBC badge</span><em>Be one of the few with the
                            Outrageous badge.</em></li>
                        <li><span class="hoverover">100 ROBUX signing bonus</span><em>Can't go wrong with free
                            ROBUX.</em></li>
                        <li><span class="hoverover">Access to BC Beta</span><em>Test new features before everyone
                            else.</em></li>
                        <li><span class="hoverover">Outrageously outrageous.</span><em>Outrageously outrageous</em></li>
                        <li style="border: 0"><span class="hoverover">Outrageous-cast with the CEO and other
                            developers</span><em>Ask your burning questions as we stream live.</em></li>
                    </ul>
                </p>
            </div>
        </div>
    </div>

            </div>
            
<div id="Footer">
    <hr/>
    <div class="FooterNav">
        <a id="ctl00_rbxFooter_PrivacyHyperLink" href="/web/20100627051438/http://www.roblox.com/info/Privacy.aspx"><b>Privacy Policy</b></a>
        &nbsp;|&nbsp; 
        <a id="ctl00_rbxFooter_AdvertiseHyperLink" href="https://web.archive.org/web/20100627051438/http://sales.roblox.com/">Advertise with Us</a>
        &nbsp;|&nbsp; 
        <a id="ctl00_rbxFooter_ContactHyperLink" href="/web/20100627051438/http://www.roblox.com/info/ContactUs.aspx">Contact Us</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_AboutHyperLink" href="/web/20100627051438/http://www.roblox.com/info/About.aspx">About Us</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_FreeGamesHyperLink" href="/web/20100627051438/http://www.roblox.com/FreeGames.aspx">Free Games</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_JobsHyperLink" href="https://web.archive.org/web/20100627051438/http://jobs.roblox.com/">Jobs</a>
    </div>
    <hr/>
    <div class="FoooterNav">
    <a href="/web/20100627051438/http://www.roblox.com/town-and-city-games" title="Town and City Games">Town and City</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/medieval-games" title="Medieval Games">Medieval</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/sci-fi-games" title="Sci-Fi Games">Sci-Fi</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/ninja-games" title="Ninja Games">Ninja</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/scary-games" title="Scary Games">Scary</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/pirate-games" title="Pirate Games">Pirate</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/adventure-games" title="Adventure Games">Adventure</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/funny-games" title="Funny Games">Funny</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/wild-west-cowboy-games" title="Wild West Cowboy Games">Wild West</a>
    <a href="/web/20100627051438/http://www.roblox.com/war-games" title="War Games">War</a>&nbsp;|&nbsp; 
    <a href="/web/20100627051438/http://www.roblox.com/skatepark-games" title="Skate Park Games">Skate Park</a>
    </div>
    <hr/>
    <p class="Legalese">
        ROBLOX, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of <a id="ctl00_rbxFooter_hlRobloxCorporation" href="/web/20100627051438/http://www.roblox.com/info/About.aspx">ROBLOX Corporation</a>, ©2010. Patents pending.
        <br/>
        ROBLOX is not sponsored, authorized or endorsed by any producer of plastic building bricks, including The LEGO Group, MEGA Brands, and K'Nex,<br/> and no resemblance to the products of these companies is intended.<br/>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="/web/20100627051438/http://www.roblox.com/info/TermsOfService.aspx">Terms and Conditions</a>.
        <br/>
    </p>
</div>
            <br/><br/><br/><br/><br/><br/><br/>
   
        </div>
    </div>
    
    
        <script src="https://web.archive.org/web/20100627051438js_/http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
        <script type="text/javascript">_uacct="UA-486632-1"; _udn="roblox.com"; urchinTracker(); __utmSetVar('Visitor/Spider');</script>
    

    
    
 
    
    

<script type="text/javascript">
//<![CDATA[
(function() {var fn = function() {Roblox.Client._LaunchGamePage = "/Install/Download.aspx";Sys.Application.remove_load(fn);};Sys.Application.add_load(fn);})();Roblox.Controls.Image.ErrorUrl = "https://web.archive.org/web/20100627051438/http://www.roblox.com/Analytics/BadHtmlImage.ashx";Roblox.Controls.Image.IE6Hack($get('ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink'));Sys.Application.initialize();
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ModalPopupBehavior, {"BackgroundCssClass":"modalBackground","CancelControlID":"ctl00_cphRoblox_HiddenField4","DropShadow":true,"OkControlID":"ctl00_cphRoblox_HiddenField5","PopupControlID":"ctl00_cphRoblox_BuyBCComparePanel","dynamicServicePath":"/Upgrades/BuildersClub.aspx","id":"myBehavior4"}, null, null, $get("ctl00_cphRoblox_HiddenField6"));
});
//]]>
</script>
</form>
    
    <script src="/web/20100627051438js_/http://www.roblox.com/js/jquery-ui-1.7.2.obc.min.js" type="text/javascript"></script>

</body>
</html>