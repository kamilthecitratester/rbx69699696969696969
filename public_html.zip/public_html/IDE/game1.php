
<title>  TEST GAME 2 V2 - FIEI-v2 </title>
<link rel="stylesheet" href="rbx2.css">
<form name="aspnetForm" method="post" action="PLAYSOLO1.LUA" id="aspnetForm">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKLTQ3NTgxNjgyNA9kFgJmD2QWBGYPZBYCAgMPFgIeB1Zpc2libGVoZAIBD2QWBmYPFgIeBFRleHRlZAICDw8WAh8AaGRkAgMPZBYCAgEPZBYCAgEPZBYEZg9kFgICAQ9kFgICAQ8WBh4GaGVpZ2h0BQI5MB4Dc3JjBTYvQWRzL0lGcmFtZUFkQ29udGVudC5hc3B4P3Nsb3Q9Um9ibG94X0dhbWVzX1RvcF83Mjh4OTAeBXdpZHRoBQM3MjhkAgEPZBYGAgEPZBYCZg9kFgQCAQ8WAh4FVmFsdWUFBjQ0MzQxMWQCAw8PFgYeCEltYWdlVXJsZB4LQ29tbWFuZE5hbWVlHg9Db21tYW5kQXJndW1lbnRkZGQCAw8PFgQfCAUGNDQzNDExHwBoZGQCBQ8PFgIfCAUGNDQzNDExZGQYFQU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMDkkU3RhdHNWaWV3Dw9kAgJkBTZjdGwwMCRjcGhSb2Jsb3gkcmJ4R2FtZXMkR2FtZXNSZXBlYXRlciRjdGwwNCRTdGF0c1ZpZXcPD2QCAmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDA1JFN0YXRzVmlldw8PZAICZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMTIkU3RhdHNWaWV3Dw9kAgJkBTZjdGwwMCRjcGhSb2Jsb3gkcmJ4R2FtZXMkR2FtZXNSZXBlYXRlciRjdGwxMCRTdGF0c1ZpZXcPD2QCAmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDE0JFN0YXRzVmlldw8PZAICZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMDIkU3RhdHNWaWV3Dw9kAgJkBTZjdGwwMCRjcGhSb2Jsb3gkcmJ4R2FtZXMkR2FtZXNSZXBlYXRlciRjdGwwOCRTdGF0c1ZpZXcPD2QCAmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDE4JFN0YXRzVmlldw8PZAICZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMTUkU3RhdHNWaWV3Dw9kAgJkBTZjdGwwMCRjcGhSb2Jsb3gkcmJ4R2FtZXMkR2FtZXNSZXBlYXRlciRjdGwxNiRTdGF0c1ZpZXcPD2QCAmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDEzJFN0YXRzVmlldw8PZAICZAUjY3RsMDAkcmJ4R29vZ2xlQW5hbHl0aWNzJE11bHRpVmlldzEPD2RmZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMDYkU3RhdHNWaWV3Dw9kAgJkBTZjdGwwMCRjcGhSb2Jsb3gkcmJ4R2FtZXMkR2FtZXNSZXBlYXRlciRjdGwwMyRTdGF0c1ZpZXcPD2QCAmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDE3JFN0YXRzVmlldw8PZAICZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMDEkU3RhdHNWaWV3Dw9kAgJkBS5jdGwwMCRjcGhCYW5uZXJBZCRHYW1lc0Jhbm5lciRBc3luY0FkTXVsdGlWaWV3Dw9kZmQFNWN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1BhZ2VBZCRBc3luY0FkTXVsdGlWaWV3Dw9kZmQFNmN0bDAwJGNwaFJvYmxveCRyYnhHYW1lcyRHYW1lc1JlcGVhdGVyJGN0bDExJFN0YXRzVmlldw8PZAICZAU2Y3RsMDAkY3BoUm9ibG94JHJieEdhbWVzJEdhbWVzUmVwZWF0ZXIkY3RsMDckU3RhdHNWaWV3Dw9kAgJkG7kQHyXTP/vBIGPM2Fpw9OXCPbc="/>


<script src="/web/20100409214230js_/http://www.FIEI_V2.com/ScriptResource.axd?d=4DlCiUcqgNm3rwxw-XjB1CYLJrM0XaBGHo4L76RYUgyUk09px-Hx5XU-TWC-cotdFySkM8v436LkzfrLOqd7373bT4CW_pWJ3Mfc0Sl5Qz7X8fbWFzsX8DHdHcxJ--BfzyNozltU2Ahoo6bwCXwYeMNu5w53TH2M9wRJDEVHrNae99xGnh7Wh8WChY5WzN6ngorTcWJfB_8YDDW157OEnow6l50tPiHTpw6HnHrShJvaR5c3Sxxt_cc6BuSYwIo7E8hKI31D4U482FA0WYyUtA2" type="text/javascript"></script>
<script src="/web/20100409214230js_/http://www.FIEI_V2.com/ScriptResource.axd?d=ct_rRJZva00_Q0Q4DGQQwPHr2_-kPVSEhjNkU599raKVZV3UuOrIZK_g83hMg0qqdYwWW2E7ob-YIw0aYzX4k5Kyz9FPliCb5oGp25Vn_N7F2cErI9Yp5OsUmc54iF4g0" type="text/javascript"></script>
<script src="/web/20100409214230js_/http://www.FIEI_V2.com/Thumbs/Asset.asmx/js" type="text/javascript"></script>
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEWAwLl867oBwLyv6KVCwLQ4fwIKagmnHcTp1k3R4se3EXgO2CvLP4="/>
    
    
    
       <div id="Header">
                <div id="Banner">
                    
                            

<div id="Options">
  <div id="Authentication">
    <span><a id="ctl00_BannerOptionsLoginView_BannerOptions_Anonymous_LoginHyperLink" href="Login/Default.aspx">Login</a></span>
  </div>
  <div id="Settings"></div>
</div>
                            <a id="Logo" href="/web/20100409214230/http://www.FIEI_V2.com/Default.aspx" style="cursor: pointer; border: none;"></a>
                        
                    
                            
<div style="float: right; width: 203px;">
 
</div>

                        
                </div>
                
<div class="Navigation">
    <ul id="ctl00_Menu_MenuUL">
        
                <li>
                    <a id="ctl00_Menu_hlMyFIEI_V2Link_hlMyFIEI_V2" href="ps1.php" style="">My FIEI_V2 (hardcoded)</a></li>
            
        <li><a id="hlGames" href="Landing.aspx" style="font-weight: bold" title="Games">Games</a>

            <ul>
                <li>
                    <div class="dropdownmainnav" style="height:250px;z-index:99999;">
                        
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Classic.png" />
                                    <a href='/all-games'
                                        title="All" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        All</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/City.png" />
                                    <a href='/town-and-city-games'
                                        title="Town and City" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Town and City</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Castle.png" />
                                    <a href='/medieval-games'
                                        title="Medieval" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Medieval</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/SciFi.png" />
                                    <a href='/sci-fi-games'
                                        title="Sci-Fi" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Sci-Fi</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Ninja.png" />
                                    <a href='/ninja-games'
                                        title="Ninja" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Ninja</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Cthulu.png" />
                                    <a href='/scary-games'
                                        title="Horror" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Horror</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Pirate.png" />
                                    <a href='/pirate-games'
                                        title="Pirate" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Pirate</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Adventure.png" />
                                    <a href='/adventure-games'
                                        title="Adventure" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Adventure</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Sports.png" />
                                    <a href='/sports-games'
                                        title="Sports" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Sports</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/LOL.png" />
                                    <a href='/funny-games'
                                        title="LOL" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        LOL</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/WildWest.png" />
                                    <a href='/wild-west-cowboy-games'
                                        title="Wild West" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Wild West</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/ModernMilitary.png" />
                                    <a href='/war-games'
                                        title="Modern Military" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Modern Military</a>
                                </div>
                            
                                <div style="float: left; width: 50%; text-align: left;">
                                    <img src="/images/GenreIconsInverted/Skatepark.png" />
                                    <a href='/skatepark-games'
                                        title="Skate Park" style="padding: 0; margin: 0 2px 0 0; border: none; font-size: 15px;">
                                        Skate Park</a>
                                </div>
                            
                    </div>
                    
                   
        </li>
        <li><a id="hlBuildersClub" href="bc.php" style="" title="Builders Club">Builders Club</a></li>
        <li><a id="hlHelp" href="eek.php" style="" title="Help">Help</a></li>
    </ul>
</div>
<table width="900px">
<tr>
<td width="143px" align="left" valign="top">

</td>
<td valign="top" width="800" align="left">  
    <div id="ItemContainer">
        <div class="StandardBoxHeader" style="width: 709px;">
            <h1 style="margin: 0; padding: 0; font-size: 16px; font-style: inherit;">
                Light Of the Gods  By Joshosh</h1>
        </div>
        <div id="Item" class="StandardBox">
            <div id="Details">
                
                        <div style="float: left; width: 420px; overflow: hidden;">
                            <div id="Thumbnail_Place">
                                <a id="ctl00_cphRoblox_AssetThumbnailImage_Place" title="Light Of the Gods  By Joshosh" onclick="var fn = function() { if (Roblox.Client.WaitForRoblox(function() { window.location = '/Login/Default.aspx?ReturnUrl=http%3a%2f%2fwww.roblox.com%2fitem.aspx%3fseoname%3dLight-Of-the-Gods-By-Joshosh%26id%3d4373322' })){tryToDownload('/install/setup.ashx'); logStatistics('playmp'); }return false; }; if (fn()) __doPostBack('ctl00$cphRoblox$AssetThumbnailImage_Place',''); else return false;" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t0bg.roblox.com/3d0843a79efd106e3bb0c60387b1a25b" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Light Of the Gods  By Joshosh"/></a>
                            </div>
                            <div id="Actions_Place">
                                <a id="ctl00_cphRoblox_FavoriteThisPlaceButton" disabled="disabled">Favorite</a>
                            </div>
                            <div id="ctl00_cphRoblox_PlayGames" class="PlayGames">
                                <div style="text-align: center; margin: 1em 5px;">
                                    
<span class="PlaceAccessIndicator"><span id="ctl00_cphRoblox_PlaceAccessIndicator_FriendsOnlyLocked" style="display: none">
    <img id="ctl00_cphRoblox_PlaceAccessIndicator_iFriendsOnly_Locked" src="/web/20100704032821im_/http://www.roblox.com/images/locked.png" alt="Locked" border="0"/>&nbsp;Friends-only</span>
    <span id="ctl00_cphRoblox_PlaceAccessIndicator_FriendsOnlyUnlocked" style="display: none">
        <img id="ctl00_cphRoblox_PlaceAccessIndicator_iFriendsOnly_Unlocked" src="/web/20100704032821im_/http://www.roblox.com/images/unlocked.png" alt="Unlocked" border="0"/>&nbsp;Friends-only:
        You have access</span> <span id="ctl00_cphRoblox_PlaceAccessIndicator_Public" style="display:inline;">
            <img id="ctl00_cphRoblox_PlaceAccessIndicator_iPublic" src="/web/20100704032821im_/http://www.roblox.com/images/public.png" alt="Public" border="0"/>&nbsp;Public</span>
    <span id="ctl00_cphRoblox_PlaceAccessIndicator_ExpiredSelf" style="display: none">
        <img id="ctl00_cphRoblox_PlaceAccessIndicator_iSelfLocked" src="/web/20100704032821im_/http://www.roblox.com/images/locked.png" alt="Locked" border="0"/>
        &nbsp;Your Turbo Builders Club or Builders Club membership has expired, so you can
        only have one open place. Your places will not be deleted, and you can <a id="ctl00_cphRoblox_PlaceAccessIndicator_RBXLDownloadLink">download the RBXL here.</a> To unlock all of your places,
        please <a href="/web/20100704032821/http://www.roblox.com/upgrades/buildersclub.aspx">re-order Turbo Builders Club or Builders
            Club </a>.<br/>
    </span><span id="ctl00_cphRoblox_PlaceAccessIndicator_ExpiredOther" style="display: none">
        <img id="ctl00_cphRoblox_PlaceAccessIndicator_iOtherLocked" src="/web/20100704032821im_/http://www.roblox.com/images/locked.png" alt="Locked" border="0"/>
        This place is locked because the creator's <a href="/web/20100704032821/http://www.roblox.com/upgrades/buildersclub.aspx">Builders
            Club / Turbo Builders Club </a>has expired. </span></span>
                                    
                                    
                                    <img id="ctl00_cphRoblox_CopyLockedIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CopyLocked.png" alt="CopyLocked" border="0"/>
                                    Copy Protection: CopyLocked
                                    <img id="ctl00_cphRoblox_GearIcon" src="/web/20100704032821im_/http://www.roblox.com/images/Suitcase16x16.png" alt="All Gear Genres" border="0"/>
                                    
                                    
                                    Gear Allowed
                                </div>
                                

<div id="PlaceLauncherStatusPanel" style="display: none; width: 300px">
    <div class="modalPopup" style="margin: 1.5em; color: Black; padding: 10px">
        <div id="Spinner" style="float:left;margin:0 1em 1em 0">
            <img id="ctl00_cphRoblox_VisitButtons_rbxPlaceLauncher_Image1" src="/web/20100704032821im_/http://www.roblox.com/images/ProgressIndicator2.gif" alt="Progress" border="0"/></div>
        <div id="Starting" style="display: inline">
            Starting Roblox...</div>
        <div id="Waiting" style="display: none">
            Waiting for a server...</div>
        <div id="Loading" style="display: none">
            A server is loading the game...</div>
        <div id="Joining" style="display: none">
            The server is ready. Joining the game...</div>
        <div id="Error" style="display: none">
            An error occurred. Please try again later.</div>
        <div id="Expired" style="display: none">
            Joining games is temporarily disabled while we upgrade. Please try again soon.</div>
        <div id="GameEnded" style="display: none">
            The game you requested has ended.</div>
        <div id="GameFull" style="display: none">
            The game you requested is currently full. Waiting for an opening...</div>
        <div id="Updating" style="display: none">
            Roblox is updating. Please wait...</div>
        <div id="Updated" style="display: none">
            Requesting a server</div>
       <div style="text-align: center; margin-top: 1em">
            <input type="button" class="Button CancelPlaceLauncherButton" value="Cancel"/>
        </div>
    </div>
</div>



<div id="InstallationInstructions" class="modalPopup blueAndWhite" style="display: none;overflow:hidden;width:380px;">
       <div style="padding: 0px 0px 10px 0px; text-align:center;">
        <div class="titleBar">
        Installation Instructions
        </div>
        
        <div id="CancelButton" onclick="return Roblox.Client._onCancel();" class="Button" style="width: 80px; margin: 0px auto;">Close Window</div>
    </div>
</div>
<div id="pluginObjDiv" style="height: 0px">
</div>


<div id="ctl00_cphRoblox_VisitButtons_FancyButtons" style="overflow: hidden; width: 400px;">
  
<div id="ctl00_cphRoblox_VisitButtons_VisitButton" style="display:inline">
  &nbsp;&nbsp;&nbsp;<button id="ctl00_cphRoblox_VisitButtons_hlSoloVisit" class="Button" onclick="window.location = 'javascript("game:load("http://n9r.ct8.pl/asset/2") game.Players:CreateLocalPlayer(0) game.Players.LocalPlayer:LoadCharacter() game:GetService("RunService"):Run()")'">Visit Solo</button>
</div>
    
    
    

</div>
<script language="javascript">    
    function redirectPlaceLauncherToLogin() {
        var baseLoginString = "/login/default.aspx?ReturnUrl=";
        var returnUrl = "/item.aspx?seoname=Light-Of-the-Gods-By-Joshosh&id=4373322";
        returnUrl = encodeURIComponent(returnUrl);
        location.href = baseLoginString + returnUrl;
    }
    function tryToDownload(url) {

        oIFrm = document.getElementById('downloadInstallerIFrame');
        oIFrm.src = url;
    }

    function logStatistics(reqType) {
        $.get("/install/VisitButtonHandler.ashx?reqtype=" + reqType, function(data) { });
    }

    $(function() {
        if (Roblox.Client.isIDE())
            $('#ctl00_cphRoblox_VisitButtons_EditButton').show();
    });
</script>
<iframe id="downloadInstallerIFrame" src="/web/20100704032821if_/http://www.roblox.com/Light-Of-the-Gods-By-Joshosh-item?id=4373322" style="visibility:hidden; height: 0px">
</iframe>

<style type="text/css">
    .VisitButton
    {
        float: left;
    }
    .VisitRow
    {
        
    }
    .VisitDivText
    {
        float: right;
        width: 490px;
        text-align: left;
    }
    .VisitDivSpacer
    {
        clear: both;
        height: 10px;
    }
</style>

<div id="GuestModePrompt" style="display: none; width: 740px" class="modalPopup">
    <div id="GuestDialog" style="margin: 1.5em">
        <div style="margin-top: 1em">
            <div style="text-align: center; margin-bottom: 10px; color: Green">You are not currently logged in. What would you like to do?</div>
            <div class="VisitDivSpacer"></div>
            <div id="ctl00_cphRoblox_VisitButtons_PlayAsGuestMPButtonDiv" class="VisitRow">
          <div class="VisitButton">
              <input name="ctl00$cphRoblox$VisitButtons$PlayAsGuestMPButton" type="button" id="ctl00_cphRoblox_VisitButtons_PlayAsGuestMPButton" class="MediumButton" style="width: 200px" value="Play as Guest" onclick="$.modal.close('#GuestModePrompt'); if (Roblox.Client.WaitForRoblox(function() { Roblox.Launch.RequestGame('PlaceLauncherStatusPanel', 4373322) })) { tryToDownload('/install/setup.ashx'); logStatistics('playasguestmp'); } return false;  "/>
          </div>
          <div class="VisitDivText">Play away. But: You will not collect any free tickets for playing. You can not save
                    high scores nor receive badges. Only few people choose ‘Play as Guest’ .</div>
          <div class="VisitDivSpacer"></div>
      </div>
      <div class="VisitRow">
          <div class="VisitButton">
              <input name="ctl00$cphRoblox$VisitButtons$CreateAccountButton" type="button" id="ctl00_cphRoblox_VisitButtons_CreateAccountButton" class="MediumButtonSignup" onclick="window.location='login/newage.aspx'" style="width: 200px; cursor: pointer" value="Create an Account"/>
          </div>
          <div class="VisitDivText">It’s FREE. Collect tickets every time you play. Trade them for cool stuff.  Track scores and get a free online profile + a free ‘world’. Most people choose this option.</div>
          <div class="VisitDivSpacer"></div>
      </div>
      <div class="VisitRow">
          <div class="VisitButton">
              <input name="ctl00$cphRoblox$VisitButtons$LoginButton" type="button" id="ctl00_cphRoblox_VisitButtons_LoginButton" class="MediumButton" onclick="redirectPlaceLauncherToLogin();return false;" style="width: 200px" value="Log in"/>
          </div>
          <div class="VisitDivText">Have an account, why start from scratch? Log in to see your place, your profile and meet your friends.</div>
          <div class="VisitDivSpacer"></div>
            </div>
      <div class="VisitRow">
                <div class="VisitButton">
                    <input type="button" class="MediumButton simplemodal-close" style="width: 200px;" value="Cancel"/>
          </div>
          <div class="VisitDivText">Wrong click? Go back.</div>
          <div class="VisitDivSpacer"></div>
      </div>
        </div>
    </div>
</div>
                                
                            </div>
                            
                            <div id="ctl00_cphRoblox_Div1" class="BadgeStats" style="margin-top: 10px;">
                                
<div class="StandardBoxHeader" style="width:388px;">Badges</div>
<div id="BadgeStats" class="StandardBox">
    
            <table border="1">
        
            <tr>
                <td>
                    <a id="ctl00_cphRoblox_PlaceBadgeStats_BadgeRepeater_ctl01_AssetThumbnailHyperLink" title="Obstacle Master" href="/web/20100704032821/http://www.roblox.com/Obstacle-Master-item?id=21044416" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t7bg.roblox.com/6dee196818563b2bbe343e43614b7bc1" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Obstacle Master" blankurl="http://t6bg.roblox.com/blank-75x75.gif"/></a>
                </td>
                <td valign="top">       
                    <a id="ctl00_cphRoblox_PlaceBadgeStats_BadgeRepeater_ctl01_AssetNameHyperLink" title="click to view" href="/web/20100704032821/http://www.roblox.com/Obstacle-Master-item?id=21044416">Obstacle Master</a>      
                    <br/><br/>
                    Finishing Joshosh's Obstacle course
                </td>
                <td valign="top">
                    Rarity: 00.0% (Impossible)<br/>
                    Won yesterday: 0<br/>
                    Won ever: 273
                </td>
            </tr>
        
            </table>
        

</div>

                            </div>
                        </div>
                    
                <div id="Summary" style="float: right;">
                    <h3>
                        ROBLOX Place
                    </h3>
                    <b></b>
                    
                    
                    
                    <div id="Creator" class="Creator">
                        <div class="Avatar">
                            
                            <a id="ctl00_cphRoblox_AvatarImage" title="Joshosh" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=214484" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t1bg.roblox.com/2b4a03aa7236c383d06a4c9d7aa7593e" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Joshosh" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a>
                        </div>
                        Creator:
                        <a id="ctl00_cphRoblox_CreatorHyperLink" href="User.aspx?ID=214484">Joshosh</a>
                    </div>
                    <div id="Div6">
                        Created:
                        9/20/2008</div>
                    <div id="LastUpdate">
                        Updated:
                        1 day ago</div>
                    <div id="Favorited">
                        Favorited:
                        1,448 times</div>
                    
                    
                    <div id="ctl00_cphRoblox_VisitedPanel" class="Visited">
                        Visited:
                        21,885 times
                    </div>
                    <div style="margin-top: 5px; margin-bottom: 5px;">
                        <div id="ctl00_cphRoblox_Genres">
  
                            Genres:
                            
                            
                            
                            
                            <div id="ctl00_cphRoblox_Panel2">
    
                                <img id="ctl00_cphRoblox_Image5" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/GenreIcons/Castle.png" alt="Fantasy" border="0"/>
                                <a href="/web/20100704032821/http://www.roblox.com/medieval-games">Fantasy</a>
                            
  </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        
</div>
                    </div>
                    <div id="ctl00_cphRoblox_GearAttributes">
  
                        <div style="margin-top: 5px; margin-bottom: 5px;">
                            Allowed Gear Types:
                            
                            <div id="ctl00_cphRoblox_IsMelee">
    
                                <img id="ctl00_cphRoblox_Image1" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CategoryIcons/Melee.png" alt="Melee" border="0"/>
                                Melee Weapon
  </div>
                            
                            
                            <div id="ctl00_cphRoblox_IsPowerup">
    
                                <img id="ctl00_cphRoblox_Image10" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CategoryIcons/PowerUps.png" alt="Power Ups" border="0"/>
                                Power Up
  </div>
                            <div id="ctl00_cphRoblox_IsNavigation">
    
                                <img id="ctl00_cphRoblox_Image11" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CategoryIcons/Navigation.png" alt="Navigation" border="0"/>
                                Navigation Enhancer
  </div>
                            <div id="ctl00_cphRoblox_IsMusical">
    
                                <img id="ctl00_cphRoblox_Image12" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CategoryIcons/Music.png" alt="Musical" border="0"/>
                                Musical Instrument
  </div>
                            <div id="ctl00_cphRoblox_IsSocial">
    
                                <img id="ctl00_cphRoblox_Image13" class="GamesInfoIcon" src="/web/20100704032821im_/http://www.roblox.com/images/CategoryIcons/Social.png" alt="Social" border="0"/>
                                Social Item
  </div>
                            
                            
                        </div>
                    
</div>
                    
                    
                    
                        
                    <div id="ReportAbuse">
                        <div id="ctl00_cphRoblox_AbuseReportButton1_AbuseReportPanel" class="ReportAbusePanel">
  
    <span class="AbuseIcon"><a id="ctl00_cphRoblox_AbuseReportButton1_ReportAbuseIconHyperLink" href="AbuseReport/Asset.aspx?ID=4373322&amp;RedirectUrl=http%3a%2f%2fwww.roblox.com%2fitem.aspx%3fseoname%3dLight-Of-the-Gods-By-Joshosh%26id%3d4373322"><img src="/web/20100704032821im_/http://www.roblox.com/images/abuse.PNG?v=2" alt="Report Abuse" border="0"/></a></span>
    <span class="AbuseButton"><a id="ctl00_cphRoblox_AbuseReportButton1_ReportAbuseTextHyperLink" href="AbuseReport/Asset.aspx?ID=4373322&amp;RedirectUrl=http%3a%2f%2fwww.roblox.com%2fitem.aspx%3fseoname%3dLight-Of-the-Gods-By-Joshosh%26id%3d4373322">Report Abuse</a></span>

</div>
                    </div>
                    
                </div>
                
                
                 
                <div style="clear: both;">
                </div>
            </div>
            
            
            <div style="margin-top: 10px;">
                <div>
                    
<div class="StandardBoxHeader">Recommendations</div>
<div class="StandardBox">
    <div style="font-size: x-small;">Here are some other free games that we think you might like.</div>
    <table id="ctl00_cphRoblox_AssetRec_dlAssets" cellspacing="0" align="Center" border="0" height="200" width="600">
NO THANKS
</div>
                </div>
            </div>
            <div style="margin: 10px; width: 703px; color: #000000;">
                <a name="tabRegion">&nbsp;</a>
                <div class="ajax__tab_xp" id="ctl00_cphRoblox_TabbedInfo">
  <div id="ctl00_cphRoblox_TabbedInfo_header">
    <span id="__tab_ctl00_cphRoblox_TabbedInfo_GamesTab">
                            <h3>
                                Games</h3>
                        </span><span id="__tab_ctl00_cphRoblox_TabbedInfo_CommentaryTab">
                            <h3>
                                Commentary</h3>
                        </span>
  </div><div id="ctl00_cphRoblox_TabbedInfo_body">
    <div id="ctl00_cphRoblox_TabbedInfo_GamesTab" style="display:none;">
      
                            <div id="ctl00_cphRoblox_TabbedInfo_GamesTab_RunningGamesUpdatePanel">
        
                                    
                                    
                                            <p style="text-align: center;">
                                                There are no running games for this place.</p>
                                        
                                    <div class="FooterPager" style="text-align: center;">
                                        
                                    </div>
                                    <div class="RefreshRunningGames">
                                        <input type="submit" name="ctl00$cphRoblox$TabbedInfo$GamesTab$RefreshRunningGamesButton" value="Refresh" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$TabbedInfo$GamesTab$RefreshRunningGamesButton&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_cphRoblox_TabbedInfo_GamesTab_RefreshRunningGamesButton" class="Button"/>
                                    </div>
                                
      </div>
                        
    </div><div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab" style="display:none;">
      
                            <div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsUpdatePanel">
        
        <div class="CommentsContainer">
            
                    <h3>Comments (296)</h3>
                    <div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl00_HeaderPagerPanel" class="HeaderPager">
                  
                  <span id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl00_HeaderPagerLabel">Page 1 of 30</span>
                  <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl00_HeaderPageSelector_Next" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$TabbedInfo$CommentaryTab$CommentsPane$CommentsRepeater$ctl00$HeaderPageSelector_Next&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))">Next <span class="NavigationIndicators">&gt;&gt;</span></a>
                </div>
                <div class="Comments">
                
                    <div class="Comment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl01_AvatarImage" title="Swordfire" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=511795" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t6bg.roblox.com/79b2be15401c16bc60777ab900af30ef" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Swordfire" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                21 hours ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl01_UsernameHyperLink" href="User.aspx?ID=511795">Swordfire</a>
                            </div>
                            <div class="Content">Very nice! Kinda laggy though...</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="AlternateComment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl02_AvatarImage" title="Josh62999" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=5343064" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bee101859babfde451df6bec262950e2" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Josh62999" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                1 day ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl02_UsernameHyperLink" href="User.aspx?ID=5343064">Josh62999</a>
                            </div>
                            <div class="Content">3Doddish you liar!</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="Comment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl03_AvatarImage" title="recentteen14" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=1273702" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/7e7fb9b2438c7c3a5df90657960de193" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="recentteen14" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                1 day ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl03_UsernameHyperLink" href="User.aspx?ID=1273702">recentteen14</a>
                            </div>
                            <div class="Content">QUIT SHUTTING GAME DOWN DANGIT! &gt;=O</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="AlternateComment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl04_AvatarImage" title="Senitachi" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=6909764" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t6bg.roblox.com/114cbd112a4171d2d1f995e5e85d6b2b" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Senitachi" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                1 day ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl04_UsernameHyperLink" href="User.aspx?ID=6909764">Senitachi</a>
                            </div>
                            <div class="Content">GAMES KEEP SHUTTING DOWND:</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="Comment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl05_AvatarImage" title="petita" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=6001293" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t4bg.roblox.com/57906893a90fdbb967c6cc14525526e0" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="petita" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                1 day ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl05_UsernameHyperLink" href="User.aspx?ID=6001293">petita</a>
                            </div>
                            <div class="Content">Why it's gone? :,(</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="AlternateComment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl06_AvatarImage" title="cooljoe582589" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=2856999" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bed4f733e1699f66a285c57eccf6aa6c" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="cooljoe582589" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                1 day ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl06_UsernameHyperLink" href="User.aspx?ID=2856999">cooljoe582589</a>
                            </div>
                            <div class="Content">its sad that its gone it was a awsome game</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="Comment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl07_AvatarImage" title="Josh62999" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=5343064" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bee101859babfde451df6bec262950e2" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Josh62999" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                2 days ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl07_UsernameHyperLink" href="User.aspx?ID=5343064">Josh62999</a>
                            </div>
                            <div class="Content">It's... gone?</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="AlternateComment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl08_AvatarImage" title="Josh62999" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=5343064" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bee101859babfde451df6bec262950e2" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Josh62999" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                2 days ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl08_UsernameHyperLink" href="User.aspx?ID=5343064">Josh62999</a>
                            </div>
                            <div class="Content">Perfect timing AGAIN!!!</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="Comment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl09_AvatarImage" title="Josh62999" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=5343064" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bee101859babfde451df6bec262950e2" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Josh62999" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                2 days ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl09_UsernameHyperLink" href="User.aspx?ID=5343064">Josh62999</a>
                            </div>
                            <div class="Content">3Doddish*</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    <div class="AlternateComment">
                        <div class="Commenter">
                            <div class="Avatar">
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl10_AvatarImage" title="Josh62999" href="/web/20100704032821/http://www.roblox.com/User.aspx?ID=5343064" style="display:inline-block;cursor:pointer;"><img src="https://web.archive.org/web/20100704032821im_/http://t2bg.roblox.com/bee101859babfde451df6bec262950e2" border="0" onerror="return Roblox.Controls.Image.OnError(this)" alt="Josh62999" blankurl="http://t6bg.roblox.com/blank-100x100.gif"/></a></div>
                        </div>
                        <div class="Post">
                            <div class="Audit">
                                Posted
                                2 days ago
                                by
                                <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl10_UsernameHyperLink" href="User.aspx?ID=5343064">Josh62999</a>
                            </div>
                            <div class="Content">Dude, my gear keeps breaking. I broke 4 pickaxes in a row, and 3 axes in a row. I also broke 2 Master Axes in a row.</div>
                            
                        </div>
                        <div style="clear: both;"></div>
                    </div>
                
                    </div>
                    <div id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl11_FooterPagerPanel" class="FooterPager">
                  
                  <span id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl11_FooterPagerLabel">Page 1 of 30</span>
                  <a id="ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl11_FooterPageSelector_Next" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$TabbedInfo$CommentaryTab$CommentsPane$CommentsRepeater$ctl11$FooterPageSelector_Next&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))">Next <span class="NavigationIndicators">&gt;&gt;</span></a>
                </div>
                
            
            
        </div>
        <script type="text/javascript" language="javascript">
            function limitText(limitField, limitNum)
            {
                if (limitField.value.length > limitNum)
                {
                    limitField.value = limitField.value.substring(0, limitNum);
                }
                $('#CharsRemaining').html(Math.max(0, Math.min(200, limitNum - limitField.value.length)) + " characters remaining");
            }
        </script>   
    
      </div>

                        
    </div>
  </div>
</div>
            </div>
            
            <div id="FreeGames">
                <span><b>Other free games and items:</b></span><ul class="freegames" style="list-style: none; text-align: center;"><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/Ninja-Shirt-item?id=4373222" title="Free Games: Ninja Shirt">Ninja Shirt</a></li><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/wwe-7-item?id=4373312" title="Free Games: wwe 7">wwe 7</a></li><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/stone-cold-steve-austin-item?id=4373321" title="Free Games: stone cold steve austin">stone cold steve austin</a></li><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/house-tycoon-item?id=4373323" title="Free Games: house tycoon">house tycoon</a></li><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/wwe-10-item?id=4373332" title="Free Games: wwe 10">wwe 10</a></li><li style="display: inline; margin-right: 10px;"><a href="/web/20100704032821/http://www.roblox.com/Mikeys-Crib-to-chill-out-item?id=4373422" title="Free Games: Mikey" s crib (to chill out)'>Mikey's Crib (to chill out)</a></li></ul><span><b>Other game genres you may like:</b></span><ul class="freegames" style="list-style: none; text-align: center;"><li style="display: inline; margin-right: 10px;"><a href="medieval-games" title="Medieval games">Medieval games</a></li><li style="display: inline; margin-right: 10px;"><a href="sci-fi-games" title="Sci-Fi games">Sci-Fi games</a></li><li style="display: inline; margin-right: 10px;"><a href="ninja-games" title="Ninja games">Ninja games</a></li><li style="display: inline; margin-right: 10px;"><a href="scary-games" title="Horror games">Horror games</a></li></ul></div>
        </div>
        <div class="Ads_WideSkyscraper">
            

<div style="overflow: hidden;">
    
<div id="ctl00_cphRoblox_adsWideSkyscraper_OutsideAdPanel" class="AdPanel">
  
            <iframe id="ctl00_cphRoblox_adsWideSkyscraper_AsyncAdIFrame" allowtransparency="true" frameborder="0" scrolling="no" height="600" src="/web/20100704032821if_/http://www.roblox.com/Ads/IFrameAdContent.aspx?v=2&amp;slot=Roblox_Item_Right_160x600&amp;format=skyscraper&amp;v=2" width="160"></iframe>

</div>
            <a id="ctl00_cphRoblox_adsWideSkyscraper_ReportAdButton" title="click to report an offensive ad" class="BadAdButton" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$adsWideSkyscraper$ReportAdButton&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))">[ report ]</a>
            
        
    

</div>
        </div>
        <div style="clear: both;"/>
    </div>
    <div id="ctl00_cphRoblox_ItemPurchasePopupPanel" class="modalPopup" style="display: none">
  
        <div id="ctl00_cphRoblox_ItemPurchasePopupUpdatePanel">
    
                
            
  </div>
    
</div>
    <div id="ctl00_cphRoblox_SalePriceConfirmPopupPanel" class="modalPopup" style="display: none">
  
        <div id="ctl00_cphRoblox_UpdatePanel1">
    
                <div id="RobloxOffer">
                    <h2>
                        <font color="red">Warning!</font></h2>
                    <p>
                        You are trying to sell this item for <b>
                            ERROR: No P2P offer price</b> ROBUX.</p>
                    <p>
                        This item normally sells for around <b>
                            </b> ROBUX.</p>
                    <p>
                        If you want, ROBLOX will purchase this item from you instantly for <b>
                            0</b> ROBUX.</p>
                    <p>
                        Minus marketplace fees, your profit would be: <b>
                            ERROR: No P2P offer price</b> ROBUX</p>
                    <p>
                        <input type="submit" name="ctl00$cphRoblox$CancelAttemptedSale" value="Cancel Sale" onclick="$find('myBehavior2').hide();WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$CancelAttemptedSale&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_cphRoblox_CancelAttemptedSale" class="MediumButton"/></p>
                    <p>
                        <input type="submit" name="ctl00$cphRoblox$SellItemToROBLOX" value="Sell to ROBLOX" onclick="document.getElementById('RobloxOffer').style.display = 'none';document.getElementById('ProcessROBLOXPurchase').style.display = 'block';WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$cphRoblox$SellItemToROBLOX&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_cphRoblox_SellItemToROBLOX" class="MediumButton"/></p>
                </div>
                <div id="ProcessROBLOXPurchase" style="margin: 2.5em auto; display: none;">
                    <div id="Div8" style="margin: 0 auto; text-align: center; vertical-align: middle;">
                        <img id="ctl00_cphRoblox_Image22" src="/web/20100704032821im_/http://www.roblox.com/images/ProgressIndicator2.gif" alt="Processing..." align="middle" border="0"/>&nbsp;&nbsp; Processing transaction
                        ...
                    </div>
                </div>
            
  </div>
    
</div>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField1" id="ctl00_cphRoblox_HiddenField1"/>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField2" id="ctl00_cphRoblox_HiddenField2"/>
    <input type="hidden" name="ctl00$cphRoblox$HiddenField3" id="ctl00_cphRoblox_HiddenField3"/>
    
    






<div id="ctl00_cphRoblox_CreateSetPanelDiv" class="createSetPanelPopup" style="width: 400px; height: 100%; padding: 0px; float: left; display: none">
  
        
      
</div>

    <script type="text/javascript" language="javascript">
        function UpdateSets(assetSetItemId, updateAllSets)
        {
            $.get(
                "/Sets/SetHandler.ashx?rqtype=getnewestversion&assetSetItemId=" + assetSetItemId + (updateAllSets ? "&allsets=true" : ""),
                function()
                {
                    $('#ctl00_cphRoblox_UpdateSet').hide("slow");
                    if (updateAllSets)
                    {
                        $('#ctl00_cphRoblox_updateSetsDiv').slideToggle("slow");
                    }
                });
        }
        $(document).ready(function()
        {
            $('.SetAddButton').click(function()
            {
                var assetId = $(this).parent().parent().attr('id').replace('setList_', '');
                var setId = $(this).children('.setId')[0].value;
                var setDivId = 'set_' + setId + '_' + assetId;
                var imgId = "waiting" + setDivId;
                $(setDivId).append("<img src='/images/spinners/spinner16x16.gif' id='" + imgId + "'");
                $.ajax(
                {
                    type: "GET",
                    async: true,
                    cache: false,
                    timeout: 50000,
                    url: "/Sets/SetHandler.ashx?rqtype=addtoset&assetId=" + assetId + "&setId=" + setId,
                    success: function(data)
                    {
                        if (data !== null)
                        {
                            // Remove that set from the list of available sets
                            $('#' + setDivId).removeClass('SetAddButton');
                            $('#' + setDivId).addClass('SetAddButtonAlreadyContainsItem');
                            $('#' + setDivId).unbind('click');
                            // Remove the spinner
                            $('#' + imgId).remove();
                        }
                    },
                    failure: function(data)
                    {
                        if (data !== null)
                        {
                            //alert("failure");
                        }
                    }
                });
            });
        });
  </script>  

            </div>
            
<div id="Footer">
    <hr/>
    <div class="FooterNav">
        <a id="ctl00_rbxFooter_PrivacyHyperLink" href="/web/20100704032821/http://www.roblox.com/info/Privacy.aspx"><b>Privacy Policy</b></a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_AdvertiseHyperLink" href="https://web.archive.org/web/20100704032821/http://sales.roblox.com/">Advertise with Us</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_ContactHyperLink" href="/web/20100704032821/http://www.roblox.com/info/ContactUs.aspx">Contact Us</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_AboutHyperLink" href="/web/20100704032821/http://www.roblox.com/info/About.aspx">About Us</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_FreeGamesHyperLink" href="/web/20100704032821/http://www.roblox.com/FreePLAYSOLO1.LUA">Free Games</a>
        &nbsp;|&nbsp;
        <a id="ctl00_rbxFooter_JobsHyperLink" href="https://web.archive.org/web/20100704032821/http://jobs.roblox.com/">Jobs</a>
    </div>
    <hr/>
    <div class="FoooterNav">
    <a href="/web/20100704032821/http://www.roblox.com/town-and-city-games" title="Town and City Games">Town and City</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/medieval-games" title="Medieval Games">Medieval</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/sci-fi-games" title="Sci-Fi Games">Sci-Fi</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/ninja-games" title="Ninja Games">Ninja</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/scary-games" title="Scary Games">Scary</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/pirate-games" title="Pirate Games">Pirate</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/adventure-games" title="Adventure Games">Adventure</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/funny-games" title="Funny Games">Funny</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/wild-west-cowboy-games" title="Wild West Cowboy Games">Wild West</a>
    <a href="/web/20100704032821/http://www.roblox.com/war-games" title="War Games">War</a>&nbsp;|&nbsp;
    <a href="/web/20100704032821/http://www.roblox.com/skatepark-games" title="Skate Park Games">Skate Park</a>
    </div>
    <hr/>
    <p class="Legalese">
        ROBLOX, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of <a id="ctl00_rbxFooter_hlRobloxCorporation" href="/web/20100704032821/http://www.roblox.com/info/About.aspx">ROBLOX Corporation</a>, ©2010. Patents pending.
        <br/>
        ROBLOX is not sponsored, authorized or endorsed by any producer of plastic building bricks, including The LEGO Group, MEGA Brands, and K'Nex,<br/> and no resemblance to the products of these companies is intended.<br/>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="/web/20100704032821/http://www.roblox.com/info/TermsOfService.aspx">Terms and Conditions</a>.
        <br/>
    </p>
</div>
            <br/><br/><br/><br/><br/><br/><br/>
   
        </div>
    </div>
    
    
        <script src="https://web.archive.org/web/20100704032821js_/http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
        <script type="text/javascript">            _uacct = "UA-486632-1"; _udn = "roblox.com"; urchinTracker(); __utmSetVar('Visitor/Spider');</script>
    

    
    
 
    
    

<script type="text/javascript">
//<![CDATA[
(function() {var fn = function() {Roblox.Client._LaunchGamePage = "/Install/Download.aspx";Sys.Application.remove_load(fn);};Sys.Application.add_load(fn);})();__utmSetVar('Roblox_Item_Top_728x90');Roblox.Controls.Image.ErrorUrl = "https://web.archive.org/web/20100704032821/http://www.roblox.com/Analytics/BadHtmlImage.ashx";Roblox.Controls.Image.IE6Hack($get('ctl00_BannerAlertsLoginView_BannerAlerts_Anonymous_rbxAlerts_SignupAndPlayHyperLink'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_PlaceBadgeStats_BadgeRepeater_ctl01_AssetThumbnailHyperLink'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl01_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl02_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl03_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl04_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl05_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl06_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl07_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl08_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl09_AvatarImage'));Roblox.Controls.Image.IE6Hack($get('ctl00_cphRoblox_TabbedInfo_CommentaryTab_CommentsPane_CommentsRepeater_ctl10_AvatarImage'));__utmSetVar('Roblox_Item_Right_160x600');Sys.Application.initialize();
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.TabPanel, {"headerTab":$get("__tab_ctl00_cphRoblox_TabbedInfo_GamesTab")}, null, {"owner":"ctl00_cphRoblox_TabbedInfo"}, $get("ctl00_cphRoblox_TabbedInfo_GamesTab"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.TabPanel, {"headerTab":$get("__tab_ctl00_cphRoblox_TabbedInfo_CommentaryTab")}, null, {"owner":"ctl00_cphRoblox_TabbedInfo"}, $get("ctl00_cphRoblox_TabbedInfo_CommentaryTab"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.TabContainer, {"activeTabIndex":0,"clientStateField":$get("ctl00_cphRoblox_TabbedInfo_ClientState")}, null, null, $get("ctl00_cphRoblox_TabbedInfo"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ModalPopupBehavior, {"BackgroundCssClass":"modalBackground","CancelControlID":"ctl00_cphRoblox_HiddenField1","DropShadow":true,"OkControlID":"ctl00_cphRoblox_HiddenField2","PopupControlID":"ctl00_cphRoblox_ItemPurchasePopupPanel","dynamicServicePath":"/item.aspx","id":"myBehavior1"}, null, null, $get("ctl00_cphRoblox_HiddenField3"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.ModalPopupBehavior, {"BackgroundCssClass":"modalBackground","CancelControlID":"ctl00_cphRoblox_HiddenField1","DropShadow":true,"OkControlID":"ctl00_cphRoblox_HiddenField2","PopupControlID":"ctl00_cphRoblox_SalePriceConfirmPopupPanel","dynamicServicePath":"/item.aspx","id":"myBehavior2"}, null, null, $get("ctl00_cphRoblox_HiddenField3"));
});
//]]>
</script>
</form>
    
    
</body>
</html>
</body>
</html>
              
              
              
              <a href="game:load("http://n9r. game.Players:CreateLocalPlayer(0) game.Players.LocalPlayer:LoadCharacter() game:GetService("RunService"):Run()">eepy</a>
